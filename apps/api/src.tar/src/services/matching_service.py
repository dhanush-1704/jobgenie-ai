from difflib import SequenceMatcher

from src.models.job import Job
from src.models.resume import Resume
from src.schemas.matching import (
    ATSBreakdown,
    MatchingResponse,
    SkillGapResponse,
)


def _normalize_skills(skills: list | None) -> set[str]:
    """
    Normalize skills for comparison.
    """

    if not skills:
        return set()

    normalized = set()

    for skill in skills:
        if skill:
            normalized.add(skill.strip().lower())

    return normalized


def _calculate_skill_similarity(
    resume_skills: set[str],
    job_skills: set[str],
) -> tuple[int, list[str], list[str]]:
    """
    Calculate percentage of required skills matched.
    """

    if not job_skills:
        return 100, [], sorted(resume_skills)

    matched = resume_skills.intersection(job_skills)
    missing = job_skills - resume_skills

    score = int(
        (len(matched) / len(job_skills)) * 100
    )

    return (
        score,
        sorted(missing),
        sorted(matched),
    )


def _description_similarity(
    resume_summary: str,
    job_description: str,
) -> int:
    """
    Lightweight similarity using SequenceMatcher.
    """

    if not resume_summary or not job_description:
        return 0

    ratio = SequenceMatcher(
        None,
        resume_summary.lower(),
        job_description.lower(),
    ).ratio()

    return int(ratio * 100)


def match_resume_to_job(
    resume: Resume,
    job: Job,
) -> MatchingResponse:
    """
    Match a parsed resume against a job.
    """

    parsed = resume.parsed_data or {}

    resume_skills = _normalize_skills(
        parsed.get("skills", [])
    )

    required_skills = _normalize_skills(
        job.required_skills
    )

    preferred_skills = _normalize_skills(
        job.preferred_skills
    )

    required_score, missing_skills, matched_skills = (
        _calculate_skill_similarity(
            resume_skills,
            required_skills,
        )
    )

    preferred_score, _, preferred_matches = (
        _calculate_skill_similarity(
            resume_skills,
            preferred_skills,
        )
    )

    summary = parsed.get(
        "summary",
        "",
    )

    description_score = _description_similarity(
        summary,
        job.description or "",
    )

    overall_score = int(
        (
            required_score * 0.60
            + preferred_score * 0.20
            + description_score * 0.20
        )
    )

    strengths = []

    if required_score >= 80:
        strengths.append(
            "Strong match for required skills."
        )

    if preferred_score >= 60:
        strengths.append(
            "Possesses several preferred skills."
        )

    if description_score >= 70:
        strengths.append(
            "Resume aligns well with the job description."
        )

    suggestions = []

    if missing_skills:
        suggestions.append(
            f"Add or strengthen these skills: {', '.join(missing_skills)}."
        )

    if description_score < 60:
        suggestions.append(
            "Improve the professional summary to better reflect the target role."
        )

    if not suggestions:
        suggestions.append(
            "Resume is well aligned with this job."
        )

    return MatchingResponse(
        overall_score=overall_score,
        ats_breakdown=ATSBreakdown(
            required_skill_score=required_score,
            preferred_skill_score=preferred_score,
            description_score=description_score,
        ),
        skill_gap=SkillGapResponse(
            matched_skills=matched_skills,
            preferred_skill_matches=preferred_matches,
            missing_skills=missing_skills,
        ),
        strengths=strengths,
        suggestions=suggestions,
    )